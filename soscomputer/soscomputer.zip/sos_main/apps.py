from django.apps import AppConfig


class SosMainConfig(AppConfig):
    name = 'sos_main'
